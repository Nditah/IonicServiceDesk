import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AbrirChamadosPage } from './abrir-chamados';

@NgModule({
  declarations: [
    AbrirChamadosPage,
  ],
  imports: [
    IonicPageModule.forChild(AbrirChamadosPage),
  ],
})
export class AbrirChamadosPageModule {}
